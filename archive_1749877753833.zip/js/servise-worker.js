const CACHE_NAME = 'expresso-burguer-v1';
const FILES_TO_CACHE = [
  '/',
  '/index.html',
  '/resumo.html',
  '/css/styles.css',
  '/js/script.js',
  '/js/resumo.js',
  '/assets/img/burger1.jpg',
  '/assets/img/burger2.jpg',
  '/assets/img/combo1.jpg',
  '/assets/img/promo1.png',
  '/assets/img/promo2.png',
  '/assets/img/promo3.png',
  '/assets/icons/icon-192.png',
  '/assets/icons/icon-512.png',
  '/manifest.json'
];

// Página offline como fallback
const OFFLINE_URL = '/offline.html';

// Instalação
self.addEventListener('install', (event) => {
  // Pré-cache arquivos estáticos + offline.html
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll([...FILES_TO_CACHE, OFFLINE_URL]);
    })
  );
  self.skipWaiting();
});

// Ativação
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keyList) => {
      return Promise.all(
        keyList.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch - estratégia Cache com fallback para offline
self.addEventListener('fetch', (event) => {
  // Só tratamos requisições GET para arquivos do mesmo domínio
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then((response) => {
      if (response) {
        return response; // retorna do cache
      }
      // Se não estiver no cache, tenta na rede
      return fetch(event.request).catch(() => {
        // Se der erro (offline), e for navegação, retorna offline.html
        if (event.request.mode === 'navigate') {
          return caches.match(OFFLINE_URL);
        }
      });
    })
  );
});