document.addEventListener("DOMContentLoaded", () => {
  // --------------------
  // Variáveis e seletores
  // --------------------
  const cart = JSON.parse(localStorage.getItem('resumoPedido')) || [];
  const cartItemsEl = document.getElementById("cartItems");
  const cartTotalEl = document.getElementById("cartTotal");
  const cartOverlay = document.getElementById("cartOverlay");
  const cartElement = document.getElementById("cart");
  const openCartBtn = document.getElementById("openCartBtn");
  const closeCartBtn = document.getElementById("closeCart");
  const btnsAddToCart = document.querySelectorAll(".btn-cart");
  const connectionStatusEl = document.getElementById("connection-status");
  const ratingsEls = document.querySelectorAll(".rating");

  // --------------------
  // Funções
  // --------------------

  function salvarCarrinho() {
    localStorage.setItem("resumoPedido", JSON.stringify(cart));
  }

  function atualizarCarrinho() {
    cartItemsEl.innerHTML = "";
    let total = 0;

    cart.forEach(item => {
      const li = document.createElement("li");
      li.innerHTML = `
        ${item.qtd}x ${item.name} - R$ ${(item.price * item.qtd).toFixed(2).replace('.', ',')}
        <button class="remove-btn" data-name="${item.name}" aria-label="Remover ${item.name}">❌</button>
      `;
      cartItemsEl.appendChild(li);
      total += item.price * item.qtd;
    });

    cartTotalEl.textContent = total.toFixed(2).replace(".", ",");

    salvarCarrinho();
  }

  function adicionarAoCarrinho(name, price) {
    const item = cart.find(i => i.name === name);
    if (item) {
      item.qtd++;
    } else {
      cart.push({ name, price, qtd: 1 });
    }
    atualizarCarrinho();
  }

  function removerDoCarrinho(name) {
    const index = cart.findIndex(i => i.name === name);
    if (index !== -1) {
      cart.splice(index, 1);
      atualizarCarrinho();
    }
  }

  function configurarAvaliacoes() {
    ratingsEls.forEach(rating => {
      const product = rating.getAttribute("data-product");
      const currentRating = parseInt(localStorage.getItem(`rating-${product}`)) || 0;

      rating.innerHTML = ""; // Limpar estrelas antigas

      for (let i = 1; i <= 5; i++) {
        const star = document.createElement("span");
        star.textContent = "⭐";
        star.style.cursor = "pointer";
        star.setAttribute("data-star", i);
        if (i <= currentRating) star.classList.add("active");
        rating.appendChild(star);
      }

      rating.addEventListener("click", (e) => {
        if (e.target.tagName === "SPAN") {
          const selected = parseInt(e.target.getAttribute("data-star"));
          localStorage.setItem(`rating-${product}`, selected);

          [...rating.children].forEach((star, idx) => {
            star.classList.toggle("active", idx < selected);
          });
        }
      });
    });
  }

  function atualizarStatusConexao() {
    if (navigator.onLine) {
      connectionStatusEl.textContent = "✅ Conectado";
      connectionStatusEl.style.backgroundColor = "#4caf50";
    } else {
      connectionStatusEl.textContent = "❌ Sem conexão";
      connectionStatusEl.style.backgroundColor = "#f44336";
    }
  }

  // Função para abrir o carrinho com bloqueio de scroll
  function abrirCarrinho() {
    cartOverlay.classList.add("show");
    cartElement.classList.add("open");
    document.body.style.overflow = "hidden"; // bloqueia scroll da página
  }

  // Função para fechar o carrinho e liberar scroll
  function fecharCarrinho() {
    cartOverlay.classList.remove("show");
    cartElement.classList.remove("open");
    document.body.style.overflow = ""; // libera scroll da página
  }

  // --------------------
  // Eventos
  // --------------------

  // Abrir carrinho
  openCartBtn.addEventListener("click", abrirCarrinho);

  // Fechar carrinho
  closeCartBtn.addEventListener("click", fecharCarrinho);

  // Fechar carrinho clicando no overlay
  cartOverlay.addEventListener("click", fecharCarrinho);

  // Fechar carrinho com tecla ESC
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && cartElement.classList.contains("open")) {
      fecharCarrinho();
    }
  });

  // Adicionar produto ao carrinho
  btnsAddToCart.forEach(btn => {
    btn.addEventListener("click", () => {
      const card = btn.closest(".product-card");
      const name = card.querySelector("h3").textContent;
      const priceText = card.querySelector("p").textContent.replace("R$", "").replace(",", ".").trim();
      const price = parseFloat(priceText);

      if (!isNaN(price)) {
        adicionarAoCarrinho(name, price);
      } else {
        console.warn("Preço inválido para o produto:", name);
      }
    });
  });

  // Remover item do carrinho (delegação)
  cartItemsEl.addEventListener("click", e => {
    if (e.target.classList.contains("remove-btn")) {
      const name = e.target.dataset.name;
      removerDoCarrinho(name);
    }
  });

  // Status de conexão
  window.addEventListener("online", atualizarStatusConexao);
  window.addEventListener("offline", atualizarStatusConexao);

  // --------------------
  // Inicialização
  // --------------------

  atualizarCarrinho();
  configurarAvaliacoes();
  atualizarStatusConexao();
});