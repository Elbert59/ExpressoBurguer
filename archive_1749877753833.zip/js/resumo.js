document.addEventListener("DOMContentLoaded", () => {
  // Seletores
  const resumoLista = document.getElementById("resumoLista");
  const resumoTotal = document.getElementById("resumoTotal");
  const btnEnviar = document.getElementById("btn-enviar");
  const inputNome = document.getElementById("input-nome");
  const inputEndereco = document.getElementById("input-endereco");

  // Pega os itens do carrinho do localStorage
  const carrinho = JSON.parse(localStorage.getItem("resumoPedido")) || [];

  // Função para atualizar o resumo na página
  function atualizarResumo() {
    resumoLista.innerHTML = "";
    let total = 0;

    if (carrinho.length === 0) {
      resumoLista.innerHTML = "<li>Seu carrinho está vazio.</li>";
      resumoTotal.textContent = "0,00";
      return;
    }

    carrinho.forEach(item => {
      const li = document.createElement("li");
      li.textContent = `${item.qtd}x ${item.name} - R$ ${(item.price * item.qtd).toFixed(2).replace('.', ',')}`;
      resumoLista.appendChild(li);
      total += item.price * item.qtd;
    });

    resumoTotal.textContent = total.toFixed(2).replace('.', ',');
  }

  // Função para enviar pedido pelo WhatsApp
  function enviarPedidoWhatsApp() {
    const nome = inputNome.value.trim();
    const endereco = inputEndereco.value.trim();

    if (!nome || !endereco) {
      alert("Por favor, preencha seu nome e endereço.");
      return;
    }

    if (carrinho.length === 0) {
      alert("Seu carrinho está vazio.");
      return;
    }

    // Monta a mensagem
    let mensagem = `*Pedido Expresso Burguer*\n\n*Cliente:* ${nome}\n*Endereço:* ${endereco}\n\n*Itens:*\n`;

    carrinho.forEach(item => {
      mensagem += `- ${item.qtd}x ${item.name} - R$ ${(item.price * item.qtd).toFixed(2).replace('.', ',')}\n`;
    });

    const total = carrinho.reduce((acc, item) => acc + item.price * item.qtd, 0);
    mensagem += `\n*Total:* R$ ${total.toFixed(2).replace('.', ',')}\n\n`;

    // Data e hora do pedido
    const dataHora = new Date().toLocaleString("pt-BR");
    mensagem += `*Data e hora:* ${dataHora}`;

    // Codifica a mensagem para URL
    const mensagemCodificada = encodeURIComponent(mensagem);

    // Número de telefone para enviar (adicione o seu número aqui com código do país e DDD)
    const numeroWhatsApp = "16502234435"; // <- substitua pelo seu número real

    // URL do WhatsApp
    const url = `https://wa.me/${numeroWhatsApp}?text=${mensagemCodificada}`;

    // Abre o WhatsApp na nova aba
    window.open(url, "_blank");
  }

  // Inicializa o resumo
  atualizarResumo();

  // Evento do botão enviar
  btnEnviar.addEventListener("click", enviarPedidoWhatsApp);
});